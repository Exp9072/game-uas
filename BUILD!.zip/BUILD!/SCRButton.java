import javax.swing.JButton;

public class SCRButton extends JButton {
    public SCRButton() {
        super("Scoreboard");
        // You can add the action handling logic for the Scoreboard button here when you're ready.
    }
}
