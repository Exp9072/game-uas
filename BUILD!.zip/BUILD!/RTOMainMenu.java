import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RTOMainMenu extends JPanel {
    private final JFrame frame;

    public RTOMainMenu(JFrame frame) {
        this.frame = frame;

        setLayout(new GridBagLayout());
        setBackground(Color.BLACK);

        JButton returnButton = new JButton("Return to Main Menu");
        returnButton.setFont(new Font("Arial", Font.PLAIN, 24));
        returnButton.setForeground(Color.WHITE);
        returnButton.setBackground(Color.RED);

        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                returnToMainMenu();
            }
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(20, 0, 0, 0);

        add(returnButton, gbc);
    }

    public void returnToMainMenu() {
        frame.getContentPane().removeAll(); // Remove all components from the content pane
        frame.getContentPane().add(this); // Add the main menu panel to the content pane
        frame.getContentPane().revalidate(); // Revalidate the components hierarchy
        frame.getContentPane().repaint(); // Repaint the frame
    }

    public void showGameOverScreen() {
        // Set the background to black
        frame.getContentPane().setBackground(Color.BLACK);

        // Create and customize the game over label
        JLabel gameOverLabel = new JLabel("Game Over");
        gameOverLabel.setFont(new Font("Arial", Font.BOLD, 36));
        gameOverLabel.setForeground(Color.RED);

        // Create a GridBagConstraints for positioning
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(100, 0, 0, 0);

        // Add the game over label to the panel
        add(gameOverLabel, gbc);

        // Repaint the panel to ensure the changes are visible
        repaint();
    }
}

